package com.example.odemopay

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import android.graphics.Bitmap
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.android.gms.mlkit.vision.codescanner.GmsBarcodeScanning
import com.google.zxing.BarcodeFormat
import com.google.zxing.qrcode.QRCodeWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

private val Blue = Color(0xFF0759C7)
private val PaleBlue = Color(0xFFEAF3FF)
private val Ink = Color(0xFF17243A)
private val Muted = Color(0xFF718096)
private val Green = Color(0xFF168653)

data class DemoTransaction(
    val id: String,
    val person: String,
    val phone: String,
    val amount: Int,
    val purpose: String,
    val time: String
)


private fun loadTransactions(raw: String?): List<DemoTransaction> {
    if (raw.isNullOrBlank()) return emptyList()
    return try {
        val array = JSONArray(raw)
        (0 until array.length()).map { i ->
            val o = array.getJSONObject(i)
            DemoTransaction(
                o.optString("id"), o.optString("person"), o.optString("phone"),
                o.optInt("amount"), o.optString("purpose"), o.optString("time")
            )
        }
    } catch (_: Exception) { emptyList() }
}

private fun saveTransactions(items: List<DemoTransaction>): String {
    val array = JSONArray()
    items.forEach { tx ->
        array.put(JSONObject().apply {
            put("id", tx.id); put("person", tx.person); put("phone", tx.phone)
            put("amount", tx.amount); put("purpose", tx.purpose); put("time", tx.time)
        })
    }
    return array.toString()
}

class MainActivity : ComponentActivity() {
    private var scannedValue by mutableStateOf<String?>(null)
    private val scanner by lazy { GmsBarcodeScanning.getClient(this) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(
                colorScheme = lightColorScheme(
                    primary = Blue, background = Color(0xFFF5F8FC),
                    surface = Color.White, onSurface = Ink
                )
            ) {
                DemoPayApp(
                    onScan = {
                        scanner.startScan()
                            .addOnSuccessListener { barcode -> scannedValue = barcode.rawValue }
                            .addOnFailureListener { scannedValue = null }
                    },
                    scannedValue = scannedValue,
                    clearScan = { scannedValue = null }
                )
            }
        }
    }
}

@Composable
fun DemoPayApp(onScan: () -> Unit, scannedValue: String?, clearScan: () -> Unit) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("o_demo_pay", Context.MODE_PRIVATE) }
    var balance by remember { mutableIntStateOf(prefs.getInt("balance", 25000)) }
    var transactions by remember { mutableStateOf(loadTransactions(prefs.getString("transactions", null))) }
    var displayName by remember { mutableStateOf(prefs.getString("display_name", "O Demo Pay Student") ?: "O Demo Pay Student") }
    LaunchedEffect(balance, transactions, displayName) {
        prefs.edit()
            .putInt("balance", balance)
            .putString("transactions", saveTransactions(transactions))
            .putString("display_name", displayName)
            .apply()
    }
    var page by remember { mutableStateOf("Home") }
    var receiver by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    var purpose by remember { mutableStateOf("Personal transfer") }
    var message by remember { mutableStateOf<String?>(null) }
    var qrText by remember { mutableStateOf("") }
    var selectedReceipt by remember { mutableStateOf<DemoTransaction?>(null) }

    LaunchedEffect(scannedValue) {
        scannedValue?.let { raw ->
            val parts = raw.split("|")
            if (parts.size >= 4 && parts[0] == "ODEMO") {
                receiver = parts[1]
                phone = parts[2]
                purpose = parts[3]
                page = "Send"
            } else {
                message = "This QR is not an O Demo Pay payment code."
            }
            clearScan()
        }
    }

    Scaffold(
        containerColor = Color(0xFFF5F8FC),
        bottomBar = {
            NavigationBar(containerColor = Color.White) {
                listOf("Home", "History", "QR", "Profile").forEach { item ->
                    NavigationBarItem(
                        selected = page == item,
                        onClick = { page = item },
                        icon = {
                            Icon(
                                when (item) {
                                    "Home" -> Icons.Default.Home
                                    "History" -> Icons.Default.ReceiptLong
                                    "QR" -> Icons.Default.QrCodeScanner
                                    else -> Icons.Default.Person
                                }, contentDescription = item
                            )
                        },
                        label = { Text(item) }
                    )
                }
            }
        }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {
            Header()
            when (page) {
                "Home" -> HomeScreen(
                    balance, transactions,
                    send = { page = "Send" },
                    scan = onScan,
                    makeQr = { page = "My QR" },
                    openHistory = { page = "History" },
                    openReceipt = { selectedReceipt = it; page = "Receipt" }
                )
                "Send" -> SendScreen(
                    receiver, { receiver = it }, phone, { phone = it },
                    amount, { amount = it }, purpose, { purpose = it },
                    balance,
                    onPay = {
                        val value = amount.toIntOrNull()
                        when {
                            receiver.isBlank() -> message = "Enter the receiver's name."
                            value == null || value <= 0 -> message = "Enter a valid amount in KGS."
                            value > balance -> message = "Not enough demo balance."
                            else -> {
                                val tx = DemoTransaction(
                                    "DEMO-${UUID.randomUUID().toString().take(8).uppercase()}",
                                    receiver.trim(), phone.trim(), value, purpose,
                                    SimpleDateFormat("dd MMM yyyy • HH:mm", Locale.getDefault()).format(Date())
                                )
                                balance -= value
                                transactions = listOf(tx) + transactions
                                selectedReceipt = tx
                                amount = ""
                                page = "Receipt"
                            }
                        }
                    },
                    onScan = onScan,
                    onContactSelect = { name, number -> receiver = name; phone = number }
                )
                "History" -> HistoryScreen(transactions) { selectedReceipt = it; page = "Receipt" }
                "QR" -> {
                    QrToolsScreen(
                        onScan = onScan,
                        onGenerate = { page = "My QR" }
                    )
                }
                "My QR" -> MyQrScreen(
                    qrText, { qrText = it },
                    onCreate = { page = "My QR Result" }
                )
                "My QR Result" -> QrResultScreen(qrText)
                "Receipt" -> selectedReceipt?.let { ReceiptScreen(it) } ?: HomeScreen(
                    balance, transactions, { page = "Send" }, onScan, { page = "My QR" },
                    { page = "History" }, { selectedReceipt = it; page = "Receipt" }
                )
                else -> ProfileScreen(balance, displayName, { displayName = it })
            }
        }
        message?.let {
            AlertDialog(
                onDismissRequest = { message = null },
                confirmButton = { TextButton(onClick = { message = null }) { Text("OK") } },
                title = { Text("Demo payment") },
                text = { Text(it) }
            )
        }
    }
}

@Composable
fun Header() {
    Column(Modifier.fillMaxWidth().background(Blue).padding(horizontal = 20.dp, vertical = 15.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(38.dp).background(Color.White, CircleShape), contentAlignment = Alignment.Center) {
                Text("O", color = Blue, fontWeight = FontWeight.Black, fontSize = 23.sp)
            }
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text("O Demo Pay", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text("A student payment simulation", color = Color.White.copy(alpha = .82f), fontSize = 11.sp)
            }
            Surface(color = Color(0xFFFFE8A3), shape = RoundedCornerShape(20.dp)) {
                Text("DEMO", Modifier.padding(horizontal = 12.dp, vertical = 6.dp), color = Color(0xFF694B00), fontWeight = FontWeight.Bold, fontSize = 11.sp)
            }
        }
    }
}

@Composable
fun DemoBanner() {
    Surface(color = Color(0xFFFFF4D6), shape = RoundedCornerShape(12.dp)) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Info, null, tint = Color(0xFF8A6200))
            Spacer(Modifier.width(8.dp))
            Text("DEMO ONLY • No real money or bank account is used.", color = Color(0xFF765500), fontSize = 12.sp, fontWeight = FontWeight.Medium)
        }
    }
}

@Composable
fun HomeScreen(
    balance: Int, transactions: List<DemoTransaction>,
    send: () -> Unit, scan: () -> Unit, makeQr: () -> Unit,
    openHistory: () -> Unit, openReceipt: (DemoTransaction) -> Unit
) {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        item { DemoBanner() }
        item {
            Card(shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = Blue)) {
                Column(Modifier.fillMaxWidth().padding(22.dp)) {
                    Text("DEMO WALLET BALANCE", color = Color.White.copy(alpha = .8f), fontSize = 12.sp)
                    Spacer(Modifier.height(8.dp))
                    Text("%,d KGS".format(balance), color = Color.White, fontSize = 32.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(5.dp))
                    Text("Fictional project balance", color = Color.White.copy(alpha = .8f), fontSize = 12.sp)
                }
            }
        }
        item {
            Text("Quick actions", fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                ActionTile("Send", Icons.Default.Send, send, Modifier.weight(1f))
                ActionTile("Scan QR", Icons.Default.QrCodeScanner, scan, Modifier.weight(1f))
                ActionTile("My QR", Icons.Default.QrCode2, makeQr, Modifier.weight(1f))
            }
        }
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Recent transactions", Modifier.weight(1f), fontWeight = FontWeight.Bold, fontSize = 18.sp)
                TextButton(onClick = openHistory) { Text("See all") }
            }
        }
        if (transactions.isEmpty()) {
            item { Text("No demo transactions yet.", color = Muted) }
        } else {
            items(transactions.take(5)) { tx -> TransactionRow(tx) { openReceipt(tx) } }
        }
    }
}

@Composable
fun ActionTile(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, click: () -> Unit, modifier: Modifier) {
    Card(onClick = click, modifier = modifier, shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
        Column(Modifier.fillMaxWidth().padding(vertical = 17.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(icon, null, tint = Blue, modifier = Modifier.size(27.dp))
            Spacer(Modifier.height(8.dp))
            Text(label, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
fun SendScreen(
    receiver: String, setReceiver: (String) -> Unit,
    phone: String, setPhone: (String) -> Unit,
    amount: String, setAmount: (String) -> Unit,
    purpose: String, setPurpose: (String) -> Unit,
    balance: Int, onPay: () -> Unit, onScan: () -> Unit,
    onContactSelect: (String, String) -> Unit
) {
    Column(Modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(13.dp)) {
        Text("Send demo money", fontSize = 23.sp, fontWeight = FontWeight.Bold)
        DemoBanner()
        Text("Available demo balance: %,d KGS".format(balance), color = Muted, fontSize = 13.sp)
        Text("Demo contacts", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Aida Example" to "+996 700 123 456", "Timur Demo" to "+996 555 000 111").forEach { contact ->
                AssistChip(
                    onClick = { onContactSelect(contact.first, contact.second) },
                    label = { Text(contact.first, fontSize = 11.sp) },
                    leadingIcon = { Icon(Icons.Default.Person, null, modifier = Modifier.size(16.dp)) }
                )
            }
        }
        OutlinedTextField(receiver, setReceiver, Modifier.fillMaxWidth(), label = { Text("Receiver full name") }, singleLine = true)
        OutlinedTextField(phone, setPhone, Modifier.fillMaxWidth(), label = { Text("Phone / account number") }, singleLine = true)
        OutlinedTextField(amount, setAmount, Modifier.fillMaxWidth(), label = { Text("Amount (KGS)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
        OutlinedTextField(purpose, setPurpose, Modifier.fillMaxWidth(), label = { Text("Payment purpose") }, singleLine = true)
        OutlinedButton(onClick = onScan, modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Default.QrCodeScanner, null); Spacer(Modifier.width(8.dp)); Text("Scan receiver QR")
        }
        Button(onClick = onPay, modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(14.dp)) {
            Text("Confirm DEMO payment")
        }
        Text("A confirmation creates a local demo transaction only.", color = Muted, fontSize = 11.sp)
    }
}

@Composable
fun HistoryScreen(transactions: List<DemoTransaction>, open: (DemoTransaction) -> Unit) {
    Column(Modifier.fillMaxSize().padding(18.dp)) {
        Text("Transaction history", fontSize = 23.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        DemoBanner()
        Spacer(Modifier.height(14.dp))
        if (transactions.isEmpty()) Text("No transactions yet.", color = Muted)
        else LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(transactions) { tx -> TransactionRow(tx) { open(tx) } }
        }
    }
}

@Composable
fun TransactionRow(tx: DemoTransaction, onClick: () -> Unit) {
    Card(onClick = onClick, colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(15.dp)) {
        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(42.dp).background(PaleBlue, CircleShape), contentAlignment = Alignment.Center) {
                Icon(Icons.Default.ArrowUpward, null, tint = Blue)
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(tx.person, fontWeight = FontWeight.SemiBold)
                Text(tx.purpose + " • " + tx.time, color = Muted, fontSize = 11.sp)
                Text(tx.id, color = Muted, fontSize = 10.sp)
            }
            Text("-%,d".format(tx.amount), color = Ink, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun QrToolsScreen(onScan: () -> Unit, onGenerate: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("QR payments", fontSize = 23.sp, fontWeight = FontWeight.Bold)
        DemoBanner()
        Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(18.dp)) {
            Column(Modifier.fillMaxWidth().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Default.QrCodeScanner, null, tint = Blue, modifier = Modifier.size(48.dp))
                Text("Scan a payment QR", fontWeight = FontWeight.Bold)
                Text("Read a compatible O Demo Pay receiver code.", color = Muted, fontSize = 12.sp)
                Button(onClick = onScan, modifier = Modifier.fillMaxWidth()) { Text("Open QR scanner") }
            }
        }
        Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(18.dp)) {
            Column(Modifier.fillMaxWidth().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Default.QrCode2, null, tint = Blue, modifier = Modifier.size(48.dp))
                Text("Create your payment QR", fontWeight = FontWeight.Bold)
                Text("Generate a QR code for someone to scan.", color = Muted, fontSize = 12.sp)
                OutlinedButton(onClick = onGenerate, modifier = Modifier.fillMaxWidth()) { Text("Generate my QR") }
            }
        }
    }
}

@Composable
fun MyQrScreen(qrText: String, setQrText: (String) -> Unit, onCreate: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Create your QR", fontSize = 23.sp, fontWeight = FontWeight.Bold)
        DemoBanner()
        OutlinedTextField(qrText, setQrText, Modifier.fillMaxWidth(), label = { Text("Your name") }, placeholder = { Text("e.g. Alex Example") })
        Text("This creates a demo-only receiver QR. Do not enter real banking credentials.", color = Muted, fontSize = 12.sp)
        Button(onClick = onCreate, enabled = qrText.isNotBlank(), modifier = Modifier.fillMaxWidth()) { Text("Generate QR code") }
        if (qrText.isNotBlank()) {
            Spacer(Modifier.height(4.dp))
            QrImage("ODEMO|${qrText.trim()}|DEMO-ACCOUNT|Project payment")
        }
    }
}

@Composable
fun QrResultScreen(name: String) {
    Column(Modifier.fillMaxSize().padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Your demo payment QR", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        DemoBanner()
        QrImage("ODEMO|${name.trim()}|DEMO-ACCOUNT|Project payment")
        Text(name, fontWeight = FontWeight.Bold, fontSize = 18.sp)
        Text("DEMO RECEIVER • NO BANK ACCOUNT", color = Muted, fontSize = 11.sp)
    }
}

@Composable
fun QrImage(value: String) {
    val bitmap = remember(value) {
        try {
            val matrix = QRCodeWriter().encode(value, BarcodeFormat.QR_CODE, 640, 640)
            Bitmap.createBitmap(640, 640, Bitmap.Config.ARGB_8888).also { bmp ->
                for (x in 0 until 640) for (y in 0 until 640) {
                    bmp.setPixel(x, y, if (matrix[x, y]) android.graphics.Color.BLACK else android.graphics.Color.WHITE)
                }
            }
        } catch (_: Exception) { null }
    }
    bitmap?.let {
        androidx.compose.foundation.Image(
            bitmap = it.asImageBitmap(), contentDescription = "Demo payment QR",
            modifier = Modifier.size(230.dp).background(Color.White)
        )
    }
}

@Composable
fun ReceiptScreen(tx: DemoTransaction) {
    Column(Modifier.fillMaxSize().padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(13.dp)) {
        Icon(Icons.Default.CheckCircle, null, tint = Green, modifier = Modifier.size(58.dp))
        Text("Demo payment successful", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Surface(color = Color(0xFFFFE8A3), shape = RoundedCornerShape(20.dp)) {
            Text("DEMO • NO REAL MONEY TRANSFERRED", Modifier.padding(horizontal = 14.dp, vertical = 8.dp), color = Color(0xFF694B00), fontWeight = FontWeight.Bold, fontSize = 11.sp)
        }
        Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(18.dp)) {
            Column(Modifier.fillMaxWidth().padding(20.dp), verticalArrangement = Arrangement.spacedBy(13.dp)) {
                Text("TRANSFER RECEIPT", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Text("%,d KGS".format(tx.amount), fontSize = 30.sp, fontWeight = FontWeight.Bold, color = Blue)
                HorizontalDivider()
                ReceiptLine("Paid to", tx.person)
                ReceiptLine("Phone / account", tx.phone.ifBlank { "Demo account" })
                ReceiptLine("Purpose", tx.purpose)
                ReceiptLine("Date & time", tx.time)
                ReceiptLine("Transaction ID", tx.id)
                ReceiptLine("Status", "DEMO SUCCESS")
                HorizontalDivider()
                Text("This receipt is for a classroom simulation only.", color = Muted, fontSize = 11.sp)
            }
        }
    }
}

@Composable
fun ReceiptLine(label: String, value: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, color = Muted, fontSize = 12.sp, modifier = Modifier.weight(1f))
        Text(value, fontWeight = FontWeight.SemiBold, fontSize = 12.sp, modifier = Modifier.weight(1.2f))
    }
}

@Composable
fun ProfileScreen(balance: Int, displayName: String, onNameChange: (String) -> Unit) {
    Column(Modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Profile", fontSize = 23.sp, fontWeight = FontWeight.Bold)
        DemoBanner()
        Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Box(Modifier.size(64.dp).background(PaleBlue, CircleShape), contentAlignment = Alignment.Center) {
                    Text(displayName.trim().take(1).uppercase().ifBlank { "O" }, color = Blue, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                }
                OutlinedTextField(
                    value = displayName,
                    onValueChange = onNameChange,
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Demo profile name") },
                    singleLine = true
                )
                Text("Demo wallet • Not connected to a bank", color = Muted, fontSize = 12.sp)
                Spacer(Modifier.height(12.dp))
                Text("Current demo balance: %,d KGS".format(balance), fontWeight = FontWeight.SemiBold)
                Text("This app does not accept deposits or send real funds.", color = Muted, fontSize = 12.sp)
            }
        }
        Text("Project build: 1.0", color = Muted, fontSize = 12.sp)
    }
}
